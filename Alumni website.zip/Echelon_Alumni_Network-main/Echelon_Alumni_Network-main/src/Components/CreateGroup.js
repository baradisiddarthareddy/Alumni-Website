import React from 'react'

export default function CreateGroup() {
  return (
    <div>CreateGroup</div>
  )
}
