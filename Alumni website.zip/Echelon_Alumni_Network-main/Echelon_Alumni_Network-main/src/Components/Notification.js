import React from 'react'

export default function Notification() {
  return (
    <div>Notification</div>
  )
}
