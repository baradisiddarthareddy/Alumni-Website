import React from 'react'

export default function MyGroup() {
  return (
    <div>MyGroup</div>
  )
}
