import React from 'react'
import './Elements.css';

export default function ViewJob() {
  return (
  <>
  <div className="containers">
    <div className="container">
        <div className="row">
            <div className="col-sm-7 my-3">
                <h1 className='my-3'>View Jobs</h1>
            </div>
        </div>
    </div>
  </div>
  </>
  )
}
