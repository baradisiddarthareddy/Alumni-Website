import React, { Component } from 'react'

export default class google extends Component {
  render() {
    return (
      <div>google</div>
    )
  }
}
